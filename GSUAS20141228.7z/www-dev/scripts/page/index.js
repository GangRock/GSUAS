/**
 * Created by shijiuwei on 2014/12/28.
 */
define(function (require) {
    require("header");
    return {};
});