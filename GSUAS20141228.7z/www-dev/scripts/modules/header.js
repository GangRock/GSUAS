/**
 * Created by shijiuwei on 2014/12/28.
 */
define(function (require) {
    require("bootstrap");
    $('.dropdown-toggle').dropdown();
});